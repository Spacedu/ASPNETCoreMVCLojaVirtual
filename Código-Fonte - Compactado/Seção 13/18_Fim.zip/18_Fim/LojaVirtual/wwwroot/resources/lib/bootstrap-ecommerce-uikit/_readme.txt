----------- About template ----------
Bootstrap Ecommerce UI kit - 2018

Ready to use components 
For ecommerce, marketplace and booking websites 

Build responsive ecommerce projects on the web with the world's most popular front-end component library.

Bootstrap-ecommerce ui kit is an open source toolkit for developing ecommerce and booking  websites with HTML, CSS, and JS. Quickly prototype with ready made blocks and plugins. Build your entire project with our styles and plugins, responsive design system. 


Ecommerce UI kit (2018, v1) is a new collection of HTML blocks and templates for any kind of ecommerce websites or landing pages. Ready to use blocks. Speed up your workflow with beautifully designed and coded components and ready to use sample pages.

Can be used for: online shopping websites, Ecommerce, Booking, Product catalogue, item showcase websites

4 page layouts, many style of design blocks.
50+ Section blocks with iconboxes and cards
images are included
Product cards and listing, grid views
Documentation included
HTML5 semantic code
CSS: Bootstrap 4, SASS files included
Plugins used: jQuery 2, Fancybox, Owl carousel...

DEMO: http://bootstrap-ecommerce.com
DOWNLOAD: http://gum.co/bootstrap-ecommerce

-------------
Created by Vosidiy M.

facebook.com/vosidiy
behance.com/vosidiy