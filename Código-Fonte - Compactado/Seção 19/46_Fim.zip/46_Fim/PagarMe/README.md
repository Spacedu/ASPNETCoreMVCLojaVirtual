# pagarme-net
> Pagar.me .Net Library

[![Build Status](https://travis-ci.org/pagarme/pagarme-net.svg?branch=master)](https://travis-ci.org/pagarme/pagarme-net)

## Support
If you have any problem or suggestion please open an issue [here](https://github.com/pagarme/pagarme-net/issues).

## License

Check [here](LICENSE).
