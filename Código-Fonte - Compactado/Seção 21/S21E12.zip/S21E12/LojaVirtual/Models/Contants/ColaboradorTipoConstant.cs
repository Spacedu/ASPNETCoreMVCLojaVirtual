﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LojaVirtual.Models.Contants
{
    public class ColaboradorTipoConstant
    {
        public const string Comum = "C";
        public const string Gerente = "G";
    }
}
