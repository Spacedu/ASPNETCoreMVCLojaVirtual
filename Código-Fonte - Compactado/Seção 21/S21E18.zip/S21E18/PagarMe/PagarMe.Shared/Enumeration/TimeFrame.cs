﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PagarMe
{
    public enum TimeFrame
    {
        [Base.EnumValue("start")] Start,
        [Base.EnumValue("end")] End

    }
}
